package address;

public class AddressException extends Exception
{
	  public AddressException(){
	  		super();
	  	}
	  	
	  public AddressException(String error){
	  		super( error );
	  	}
}
