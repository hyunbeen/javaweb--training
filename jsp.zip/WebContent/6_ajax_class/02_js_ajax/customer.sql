create table ajax_temp (
	name 	varchar2(10)     not null,
 	age 	varchar2(4) 		not null,
  	tel 	varchar2(14) 	not null,
	addr 	varchar2(50) 	not null
)